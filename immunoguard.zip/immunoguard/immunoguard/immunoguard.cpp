#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>
#include <iomanip>
#include <limits>
#include <sstream>
#include <conio.h> 
#include <cstdlib> 
using namespace std;
const string RESET = "\033[0m";
const string RED = "\033[31m";
const string GREEN = "\033[32m";
const string YELLOW = "\033[33m";
const string BLUE = "\033[34m";
const string MAGENTA = "\033[35m";
const string CYAN = "\033[36m";
const string WHITE = "\033[37m";
struct Vaccine {
    string name;
    int dose;
    string due_date;
    string status;
};
struct Adultvaccine {
    string name;
    string due_date;
    string status;
};
vector<Vaccine> vaccines;
struct User {
    string name;
    string password;
    string email;
    string dob;  // For child, DOB is important for calculating vaccine dates
};
tm stringToDate(const string& dateStr) {
    tm tmDate = {};
    char delimiter;
    istringstream ss(dateStr);

    // Parse date
    ss >> tmDate.tm_mday >> delimiter >> tmDate.tm_mon >> delimiter >> tmDate.tm_year;
    if (ss.fail() || delimiter != '/' || tmDate.tm_mday < 1 || tmDate.tm_mon < 1 || tmDate.tm_mon > 12 || tmDate.tm_year < 1900) {
        throw invalid_argument("Invalid date format");
    }

    tmDate.tm_mon -= 1;    // tm_mon is 0-based
    tmDate.tm_year -= 1900; // tm_year is years since 1900
    return tmDate;
}
// Vaccine schedule for children (using an array instead of unordered_map)
Vaccine vaccineSchedule[20];  // Adjust size as needed

// Function declarations
void adminLogin();
void adminDashboard();
void userPage();
void childOrAdult();
void signupPage(const string& userType);
void loginPage(const string& userType);
void childSignup();
void adultSignup();
void childLogin();
void adultLogin();
void childDashboard(const string& name, vector<Vaccine>& schedule);
void adultDashboard();
void displayWelcomePage();
void searchUserByName(const string& name);
void loginPage(const string& userType) {
    if (userType == "child") {
        childLogin();
    }
    else if (userType == "adult") {
        adultLogin();
    }
    else {
        cout << "\nInvalid user type\n";
    }
}


int chilcount = 0;
int aducount = 0;
string calculate_date(const tm& start_date, int days_after) {
    tm result_tm = start_date;
    time_t time_since_epoch = mktime(&result_tm);
    time_since_epoch += days_after * 24 * 60 * 60; // Add days in seconds

    tm future_tm; // Declare a local tm structure
    localtime_s(&future_tm, &time_since_epoch); // Safe version of localtime

    stringstream ss;
    ss << put_time(&future_tm, "%d/%m/%Y");
    return ss.str();
}

vector<Vaccine> generate_vaccine_schedule(const string& dob) {
    tm dob_tm = stringToDate(dob);

    return {
        {"BCG, ", 1, dob, "[ ]"},
        {"Hepatitis B", 1, dob, "[ ]"},
        {"OPV", 1, dob, "[ ]"},
        {"Pentavalent", 1, calculate_date(dob_tm, 42), "[ ]"},
        {"IPV", 1, calculate_date(dob_tm, 43), "[ ]"},
        {"PCV", 1, calculate_date(dob_tm, 44), "[ ]"},
        {"Rotavirus", 1, calculate_date(dob_tm, 45), "[ ]"},
        {"Pentavalent", 2, calculate_date(dob_tm, 147), "[ ]"},
         {"IPV", 2, calculate_date(dob_tm, 148), "[ ]"},
          {"PCV", 2, calculate_date(dob_tm, 149), "[ ]"},
           {"Rotavirus", 2, calculate_date(dob_tm, 150), "[ ]"},
        {"Pentavalent", 3, calculate_date(dob_tm, 334), "[ ]"},
    { "IPV", 3, calculate_date(dob_tm, 335), "[ ]" },
    { "PCV", 3, calculate_date(dob_tm, 336), "[ ]" },
    { "Rotavirus", 3, calculate_date(dob_tm, 337), "[ ]" },
        {"Influenza", 1, calculate_date(dob_tm, 153), "[ ]"},
        {"Influenza", 2, calculate_date(dob_tm, 915), "[ ]"},
        {"Measles-Rubella", 1, calculate_date(dob_tm, 279), "[ ]"},
        {"Vitamin A", 1, calculate_date(dob_tm, 280), "[ ]"},
        {"Hepatitis A", 1, calculate_date(dob_tm, 365), "[ ]"},
        {"Hepatitis A", 2, calculate_date(dob_tm, 912), "[ ]"},
        {"DPT Booster, OPV Booster", 1, calculate_date(dob_tm, 1460), "[ ]"},
        {"OPV Booster", 1, calculate_date(dob_tm, 1463), "[ ]"}
    };
}
void print_and_append_vaccine_table(const string& name, const vector<Vaccine>& schedule) {
    // Print to console
    cout << CYAN << "\nVaccine Schedule for " << name << ":\n";
    cout << left << setw(35) << "Vaccine"
        << setw(10) << "Dose #"
        << setw(15) << "Due Date"
        << "Status" << endl;
    cout << string(70, '-') << endl;

    for (const auto& vaccine : schedule) {
        cout << left << setw(35) << vaccine.name
            << setw(10) << vaccine.dose
            << setw(15) << vaccine.due_date
            << vaccine.status << endl;
    }

    // Append to file
    string fileName = name + "_vaccine_schedule.txt";
    ofstream file(fileName, ios::app);

    if (file.is_open()) {
        file << CYAN << "\nVaccine Schedule for " << name << ":\n";
        file << left << setw(35) << "Vaccine"
            << setw(10) << "Dose #"
            << setw(15) << "Due Date"
            << "Status" << endl;
        file << string(70, '-') << endl;

        for (const auto& vaccine : schedule) {
            file << left << setw(35) << vaccine.name
                << setw(10) << vaccine.dose
                << setw(15) << vaccine.due_date
                << vaccine.status << endl;
        }

        file.close();
        cout << CYAN << "Vaccine schedule successfully saved to " << fileName << ".\n";
    }
    else {
        cerr << RED << "Error: Could not open file " << fileName << " for writing.\n";
    }
}

void initializeUserCounts() {
    ifstream childFile("child_data.txt");
    ifstream adultFile("adult_data.txt");

    chilcount = 0;
    aducount = 0;

    string storedName, storedPassword, email, dob;
    while (childFile >> storedName >> storedPassword >> email >> dob) {
        chilcount++;
    }

    while (adultFile >> storedName >> storedPassword >> email) {
        aducount++;
    }

    childFile.close();
    adultFile.close();
}
void updateUserCounts() {
    ofstream countFile("user_counts.txt");
    countFile << CYAN << "Child Users: " << chilcount << endl;
    countFile << CYAN << "Adult Users: " << aducount << endl;
    countFile.close();
}
// Admin login function (check from file)
void adminLogin() {
    string username, password;
    cout << CYAN << "\nAdmin Login\n";
    cout << "Enter Username: ";
    cin >> username;
    cout << "Enter Password: ";
    cin >> password;

    ifstream file("admin.txt"); // File containing admin login data
    string storedUsername, storedPassword;
    bool found = false;

    // Check if the admin username and password match the file
    while (file >> storedUsername >> storedPassword) {
        if (storedUsername == username && storedPassword == password) {
            found = true;
            break;
        }
    }
    file.close();

    if (found) {
        system("clear");
        cout << "\nWelcome Admin\n";
        adminDashboard();
    }
    else {
        cout << RED << "\nInvalid credentials\n";
        system("clear");
        displayWelcomePage();
    }
}

// Function to handle user page
void userPage() {
    cout << YELLOW << "\nUser Page\n";
    childOrAdult();
}

// Function to ask if user is child or adult
void childOrAdult() {
    char choice;
    cout << CYAN << "\nAre you a Child or Adult? (C/A): ";
    cin >> choice;

    if (choice == 'C' || choice == 'c') {
        cout << CYAN << "\nChild Selected\n";
        cout << "Are you new? (Y/N): ";
        cin >> choice;
        if (choice == 'Y' || choice == 'y') {
            signupPage("child");
        }
        else {
            loginPage("child");
        }
    }
    else if (choice == 'A' || choice == 'a') {
        cout << CYAN << "\nAdult Selected\n";
        cout << "Are you new? (Y/N): ";
        cin >> choice;
        if (choice == 'Y' || choice == 'y') {
            system("clear");
            signupPage("adult");
        }
        else {
            system("clear");
            loginPage("adult");
        }
    }
    else {
        cout << RED << "\nInvalid choice\n";
    }
}

// Function to open signup page
void signupPage(const string& userType) {
    if (userType == "child") {
        childSignup();
    }
    else if (userType == "adult") {
        adultSignup();
    }
}
void childSignup() {
    string name, password, email, dob;

    cout << CYAN << "\n=============================\n";
    cout << "    Child Signup\n";
    cout << "=============================\n";
    cout << "Enter Name: ";
    cin.ignore();
    getline(cin, name); // Allows spaces in the name
    cout << YELLOW << "Enter Password: ";

    // Hide password input using _getch()
    char ch;
    while (true) {
        ch = _getch();  // Get a single character from input
        if (ch == 13) { // Enter key
            break;
        }
        else if (ch == 8) { // Backspace key
            if (!password.empty()) {
                password.pop_back();
                cout << "\b \b";  // Move cursor back, delete previous character
            }
        }
        else {
            password.push_back(ch);
            cout << "*";  // Print * for each entered character
        }
    }

    cout << YELLOW << "\nEnter Email: ";
    cin >> email;
    cout << "Enter Date of Birth (DD/MM/YYYY): ";
    cin >> dob;

    try {
        tm dob_tm = stringToDate(dob);  // Assuming stringToDate is implemented

        // Generate vaccine schedule
        vector<Vaccine> schedule = generate_vaccine_schedule(dob);

        // Print and save schedule
        // print_and_append_vaccine_table(name, schedule);

        // Save child data
        ofstream file("child_data.txt", ios::app);
        if (file.is_open()) {
            // Write password as asterisks in the file
            file << name << " " << password << " " << email << " " << dob << endl;
            file.close();
            chilcount++;
            cout << CYAN << "\nSignup Successful. You can now log in.\n";
            system("clear");
            loginPage("child");
        }
        else {
            cerr << RED << "Error: Could not save child data.\n";
        }
    }
    catch (const invalid_argument& e) {
        cerr << "Error: " << e.what() << "\n";
    }
}
// Function for adult signup
void adultSignup() {
    string name, password, email;

    cout << CYAN << "\n=============================\n";
    cout << "    Adult Signup\n";
    cout << "=============================\n";
    cout << YELLOW << "Enter Name: ";
    cin >> name;
    cout << YELLOW << "Enter Password: ";

    // Hide password input using _getch()
    char ch;
    while (true) {
        ch = _getch();  // Get a single character from input
        if (ch == 13) { // Enter key
            break;
        }
        else if (ch == 8) { // Backspace key
            if (!password.empty()) {
                password.pop_back();
                cout << "\b \b";  // Move cursor back, delete previous character
            }
        }
        else {
            password.push_back(ch);
            cout << "*";  // Print * for each entered character
        }
    }

    cout << YELLOW << "\nEnter Email: ";
    cin >> email;

    // Save adult data to a file
    ofstream file("adult_data.txt", ios::app);
    if (file.is_open()) {
        // Write password as asterisks in the file (or store original password if preferred)
        file << name << " " << string(password.length(), '*') << " " << email << endl;
        file.close();
        aducount++;
        cout << "\nSignup Successful. You can now log in.\n";
        system("clear");
        loginPage("adult");  // Assuming this function handles adult login
    }
    else {
        cout << "Error: Could not save adult data.\n";
    }
}
void childLogin() {
    string name, password, storedName, storedPassword, email, dob;
    bool found = false;

    cout << CYAN << "\n=============================\n";
    cout << "    Child Login\n";
    cout << "=============================\n";
    cout << YELLOW << "Enter Name: ";
    cin >> name;
    cout << YELLOW << "Enter Password: ";

    // Hide password input using _getch()
    char ch;
    while (true) {
        ch = _getch();  // Get a single character from input
        if (ch == 13) { // Enter key
            break;
        }
        else if (ch == 8) { // Backspace key
            if (!password.empty()) {
                password.pop_back();
                cout << "\b \b";  // Move cursor back, delete previous character
            }
        }
        else {
            password.push_back(ch);
            cout << "*";  // Print * for each entered character
        }
    }

    ifstream file("child_data.txt");
    if (file.is_open()) {
        while (file >> storedName >> storedPassword >> email >> dob) {
            if (storedName == name && storedPassword == password) {
                found = true;
                break;
            }
        }
        file.close();
    }

    if (found) {
        cout << "\nLogin Successful\n";
        vector<Vaccine> schedule = generate_vaccine_schedule(dob);
        // This function will print the table and append it to the file
        print_and_append_vaccine_table(name, schedule);
        childDashboard(name, schedule);
    }
    else {
        cout << "\nInvalid login details\n";
        userPage();
    }
}
void adultLogin() {
    string name, password;
    cout << GREEN<<"\n=============================\n";
    cout << GREEN << "    Adult Login\n";
    cout << GREEN << "=============================\n";
    cout << "Enter Name: ";
    cin >> name;
    cout << "Enter Password: ";

    // Hide password input using _getch()
    char ch;
    while (true) {
        ch = _getch();  // Get a single character from input
        if (ch == 13) { // Enter key
            break;
        }
        else if (ch == 8) { // Backspace key
            if (!password.empty()) {
                password.pop_back();
                cout << "\b \b";  // Move cursor back, delete previous character
            }
        }
        else {
            password.push_back(ch);
            cout << "*";  // Print * for each entered character
        }
    }

    // Check adult login from file
    ifstream file("adult_data.txt");
    string storedName, storedPassword, email;
    bool found = false;
    while (file >> storedName >> storedPassword >> email) {
        if (storedName == name && storedPassword == password) {
            found = true;
            break;
        }
    }
    file.close();

    if (found) {
        cout << "\nLogin Successful\n";

        // Create or load the vaccine schedule for the logged-in user
        vector<Adultvaccine> schedule;

        // Example: Load from a file (if applicable)
        ifstream scheduleFile("adult_vaccine_schedule.txt");
        if (scheduleFile.is_open()) {
            string vaccineName, dueDate, status;
            while (scheduleFile >> vaccineName >> dueDate >> status) {
                schedule.push_back({ vaccineName, dueDate, status });
            }
            scheduleFile.close();
        }

        // Call the adult dashboard with the schedule
        adultDashboard();
    }
    else {
        cout << "\nInvalid login details\n";
        userPage();
    }
}
// Add additional vaccines
void addAdditionalVaccines(vector<Vaccine>& schedule) {
    string vaccineName;
    int numDoses;
    string startDate;

    cout << "Enter the additional vaccine name: ";
    cin.ignore();
    getline(cin, vaccineName);

    cout << "Enter the number of doses: ";
    cin >> numDoses;

    cout << "Enter the start date (DD/MM/YYYY): ";
    cin >> startDate;

    try {
        tm start_tm = stringToDate(startDate);

        for (int i = 0; i < numDoses; ++i) {
            string dueDate = calculate_date(start_tm, i * 30);

            Vaccine additionalVaccine = { vaccineName, i + 1, dueDate, "[ ]" };
            schedule.push_back(additionalVaccine);

            // Save to file
            ofstream file("additional_vaccines.txt", ios::app);
            if (file.is_open()) {
                file << vaccineName << " " << (i + 1) << " " << dueDate << " [ ]\n";
                file.close();
            }
            else {
                cerr << "Error: Could not save additional vaccines.\n";
            }
        }

        cout << "Additional vaccines have been added successfully!\n";
    }
    catch (const invalid_argument& e) {
        cerr << "Error: " << e.what() << "\n";
    }
}
void selectionSortSchedule(vector<Vaccine>& schedule) {
    int n = schedule.size();

    for (int i = 0; i < n - 1; i++) {
        // Find the index of the minimum due date in the remaining unsorted portion
        int minIndex = i;

        for (int j = i + 1; j < n; j++) {
            if (schedule[j].due_date < schedule[minIndex].due_date) {
                minIndex = j;
            }
        }

        // Swap the current element with the minimum element
        if (minIndex != i) {
            swap(schedule[i], schedule[minIndex]);
        }
    }
}
// Function to read vaccine schedule from a file
void readVaccineScheduleFromFile(vector<Vaccine>& schedule, const string& file_name) {
    ifstream file(file_name);
    string line;
    schedule.clear();  // Clear the existing schedule before reading from the file

    while (getline(file, line)) {
        stringstream ss(line);
        Vaccine vaccine;
        ss >> vaccine.name >> vaccine.dose >> vaccine.due_date >> vaccine.status;
        schedule.push_back(vaccine);
    }

    file.close();
}
void childDashboard(const string& name, vector<Vaccine>& schedule) {
    // Sort the schedule by due date using selection sort
    selectionSortSchedule(schedule);

    // Find the next vaccine
    Vaccine* next_vaccine = nullptr;
    for (auto& vaccine : schedule) {
        if (vaccine.status == "[ ]") { // Check for the next uncompleted vaccine
            next_vaccine = &vaccine;
            break;
        }
    }

    // Display the reminder message if there's an upcoming vaccine
    if (next_vaccine) {
        cout << "\n*\n";
        cout << "Reminder: Your next vaccine is '" << next_vaccine->name
            << "', Dose " << next_vaccine->dose
            << " on " << next_vaccine->due_date << ".\n";
        cout << "Please ensure to complete it on time!\n";
        cout << "*\n";
    }
    else {
        cout << "\nNo upcoming vaccines! All caught up!\n";
    }

    // Main dashboard functionality
    int choice;
    vector<Vaccine> completed, remaining, rescheduled, additional;

    do {
        cout << "\n**** WELCOME TO CHILD DASHBOARD *****" << endl;
        cout << "1. View All Vaccines\n";
        cout << "2. Mark Completed Vaccines\n";
        cout << "3. View Remaining Vaccines\n";
        cout << "4. Reschedule Vaccines\n";
        cout << "5. Add Additional Vaccines\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: // View all vaccines
            cout << "\nAll Vaccines:\n";
            try {
                // Call the table printing function to display the schedule
                // This function should print with the updated status for each vaccine
                print_and_append_vaccine_table(name, schedule);
            }
            catch (const exception& e) {
                cerr << "Error displaying vaccine schedule: " << e.what() << endl;
            }
            break;

        case 2: { // Mark completed vaccines
            for (auto& vaccine : schedule) {
                if (vaccine.status == "[ ]") {
                    string mark;
                    cout << "Mark vaccine '" << vaccine.name
                        << "', Dose " << vaccine.dose << " as completed? (y/n): ";
                    cin >> mark;
                    if (mark == "y") {
                        vaccine.status = "[Yes]";  // Mark as completed
                        completed.push_back(vaccine);
                    }
                    else {
                        remaining.push_back(vaccine);
                    }
                }
            }
            // Update the reminder message based on the completed vaccines
            next_vaccine = nullptr;  // Recheck the reminder after completing any vaccines
            for (auto& vaccine : schedule) {
                if (vaccine.status == "[ ]") {
                    next_vaccine = &vaccine;
                    break;
                }
            }

            // Display updated reminder message
            if (next_vaccine) {
                cout << "\n*\n";
                cout <<YELLOW<< "Reminder: Your next vaccine is '" << next_vaccine->name
                    << YELLOW << "', Dose " << next_vaccine->dose
                    << YELLOW << " on " << next_vaccine->due_date << ".\n";
                 cout << YELLOW<<"Please ensure to complete it on time!\n";
                cout << YELLOW << "*\n";
            }
            else {
                cout <<GREEN<< "\nNo upcoming vaccines! All caught up!\n";
            }
            break;
        }

        case 3: // View remaining vaccines
            cout << "\nRemaining Vaccines:\n";
            for (const auto& vaccine : schedule) {
                if (vaccine.status == "[ ]") {
                    cout << left << setw(35) << vaccine.name
                        << setw(10) << vaccine.dose
                        << setw(15) << vaccine.due_date
                        << vaccine.status << endl;
                }
            }
            break;

        case 4: { // Reschedule vaccines
            string vaccine_name, new_date;
            int dose;
            bool found = false;  // Flag to check if the vaccine is found
            cout << "Enter vaccine name to reschedule: ";
            cin.ignore();
            getline(cin, vaccine_name);
            cout << "Enter dose number: ";
            cin >> dose;
            cout << "Enter new due date (YYYY-MM-DD): ";
            cin >> new_date;

            for (auto& vaccine : schedule) {
                if (vaccine.name == vaccine_name && vaccine.dose == dose) {
                    found = true;  // Vaccine found in the schedule
                    if (vaccine.status == "[Completed]") {
                        // Vaccine status is already completed, do not reschedule
                        cout << "This vaccine is already completed. Cannot reschedule.\n";
                        break;
                    }
                    else {
                        // Reschedule the vaccine
                        vaccine.due_date = new_date;
                        vaccine.status = "[Rescheduled]";
                        rescheduled.push_back(vaccine);
                        cout << "Vaccine '" << vaccine_name << "' (Dose " << dose << ") has been rescheduled to " << new_date << ".\n";
                        break;
                    }
                }
            }

            if (!found) {
                // Vaccine not found in the table
                cout << "Vaccine '" << vaccine_name << "' (Dose " << dose << ") not present in the schedule.\n";
            }

            break;
        }

        case 5: { // Add additional vaccines
            addAdditionalVaccines(schedule);
            break;
        }

        case 6: // Exit
            cout << "\nExiting dashboard...\n";
            break;

        default:
            cout << "\nInvalid choice! Try again.\n";
        }
    } while (choice != 6);

    // Save updated schedule to file
    print_and_append_vaccine_table(name, schedule);
}
vector<Adultvaccine> vaccineList;  // Vector to store vaccines

// Function to print the vaccine schedule
void printVaccineSchedule() {
    cout << "\nVaccine Schedule:\n";
    cout << "--------------------------------------------\n";
    cout << "Vaccine Name     | Due Date    | Status\n";
    cout << "--------------------------------------------\n";

    // Iterate over the vector to print the vaccine details
    for (auto& vaccine : vaccineList) {
        cout << vaccine.name << "  | " << vaccine.due_date << "  | " << vaccine.status << endl;
    }
    cout << "--------------------------------------------\n";
}

// Function to save the vaccine schedule to a file
void saveVaccineScheduleToFile() {
    ofstream outFile("adult_vaccine_schedule.txt", ios::trunc);  // Use trunc to overwrite the file each time

    // Write table headers
    outFile << "Vaccine Name     | Due Date    | Status\n";
    outFile << "--------------------------------------------\n";

    // Write vaccine data
    for (auto& vaccine : vaccineList) {
        outFile << vaccine.name << "     | " << vaccine.due_date << "  | " << vaccine.status << endl;
    }

    // Close the file after writing
    outFile.close();
}


// Function for adding vaccines
void addVaccines() {
    string vaccineName;
    string dueDate;
    string status;

    // Ask for vaccine name and due date
    cout << "Enter vaccine name: ";
    cin.ignore();  // To ignore the leftover newline character
    getline(cin, vaccineName);
    cout << "Enter due date (YYYY-MM-DD): ";
    cin >> dueDate;

    // Ask for status (Completed/Not Completed)
    cout << "Enter vaccine status (Completed/Not Completed): ";
    cin.ignore();
    getline(cin, status);

    // Store vaccine data in the vector
    vaccineList.push_back({ vaccineName, dueDate, status });

    // Print the updated vaccine schedule
    printVaccineSchedule();

    // Save to the file
    saveVaccineScheduleToFile();
}

// Function for checking the checklist
void checkChecklist() {
    printVaccineSchedule();

    string vaccineName;
    string status;

    cout << "\nUpdate vaccine status (Completed or Not Completed)\n";
    cout << "Enter vaccine name to update status: ";
    cin.ignore();  // To ignore the leftover newline character
    getline(cin, vaccineName);

    // Find the vaccine in the list and update status
    for (auto& vaccine : vaccineList) {
        if (vaccine.name == vaccineName) {
            cout << "Enter new status (Completed/Not Completed): ";
            getline(cin, status);
            vaccine.status = status;
        }
    }

    // Print the updated vaccine schedule
    printVaccineSchedule();

    // Save to the file
    saveVaccineScheduleToFile();
}

// Function for rescheduling vaccines
void rescheduleVaccines() {
    string vaccineName;
    string newDueDate;

    cout << CYAN << "\nReschedule a vaccine\n";
    cout << "Enter vaccine name to reschedule: ";
    cin.ignore();  // To ignore the leftover newline character
    getline(cin, vaccineName);

    // Find the vaccine in the list and update the due date
    for (auto& vaccine : vaccineList) {
        if (vaccine.name == vaccineName) {
            cout << "Enter new due date (YYYY-MM-DD): ";
            cin >> newDueDate;
            vaccine.due_date = newDueDate;
        }
    }

    // Print the updated vaccine schedule
    printVaccineSchedule();

    // Save to the file
    saveVaccineScheduleToFile();
}
void adultDashboard() {
    int choice;

    while (true) {
        cout << CYAN << "\nAdult Dashboard\n";
        cout << "1. Add vaccines\n";
        cout << "2. Checklist\n";
        cout << "3. Reschedule\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            addVaccines();
            break;
        case 2:
            checkChecklist();
            break;
        case 3:
            rescheduleVaccines();
            break;
        case 4:
            cout << "Exiting dashboard...\n";
            return;
        default:
            cout << RED << "Invalid choice. Please try again.\n";
        }
    }
}
void adminDashboard() {
    int choice;
    do {
        cout << YELLOW << "\n=============================\n";
        cout << YELLOW << "   Admin Dashboard\n";
        cout << YELLOW << "=============================\n";
        cout << "1. Total Users\n";
        cout << "2. Child Users\n";
        cout << "3. Adult Users\n";
        cout << "4. Search by Name\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "\ntotal users\n";
            cout << chilcount + aducount;
            break;
        case 2:
            cout << CYAN << "\nDisplaying child users...\n";
            cout << chilcount;
            break;
        case 3:
            cout << CYAN << "\nDisplaying adult users...\n";
            cout << aducount;
            break;
        case 4:
        {
            string nameToSearch;
            cout << CYAN << "Enter the name to search: ";
            cin >> nameToSearch;

            searchUserByName(nameToSearch);
            break;
        }

        case 5:
            cout << CYAN << "Exiting....";
            system("clear");
            displayWelcomePage();
            break;
        default:
            cout << RED << "\nInvalid choice\n";
        }
    } while (choice != 5);
}
void printTable(const vector<string>& tableData) {
    if (tableData.empty()) {
        cout << CYAN << "No vaccine schedule found in the file.\n";
        return;
    }

    cout << left << setw(35) << "Vaccine" << setw(10) << "Dose #" << setw(15) << "Due Date" << setw(10) << "Status" << endl;
    cout << string(70, '-') << endl;

    for (const string& row : tableData) {
        cout << row << endl;
    }
}

// Function to search and display the last vaccine schedule for a user
void searchUserByName(const string& name) {
    string fileName = name + "_vaccine_schedule.txt"; // Construct the file name dynamically

    ifstream file(fileName); // Open the user's vaccine schedule file
    if (!file) {
        cerr << RED << "Error: File for " << name << RED << " not found or could not be opened.\n";
        return;
    }

    string line;
    vector<string> currentTable;
    vector<string> lastTable; // To store the last table

    while (getline(file, line)) {
        if (line.find("Vaccine") != string::npos) {
            // If a new table starts, save the current one as the last table
            if (!currentTable.empty()) {
                lastTable = currentTable;
                currentTable.clear();
            }
            // Add the header for the new table
            currentTable.push_back(line);
        }
        else if (!line.empty()) {
            // Add rows to the current table
            currentTable.push_back(line);
        }
    }

    // After the loop, the last table is either in currentTable or lastTable
    if (!currentTable.empty()) {
        lastTable = currentTable;
    }

    file.close();

    // Print the last table
    cout << YELLOW << "\nVaccine Schedule for " << name << ":\n";
    printTable(lastTable);
}
void displayWelcomePage() {
    char choice;
    cout << YELLOW << "\n=============================\n";
    cout << YELLOW<< "    IMMUNOGUARD WELCOME PAGE\n";
    cout << YELLOW << "=============================\n";
    cout << CYAN<<"\nChoose Option:\n";
    cout << CYAN << "1. Admin Login (A)\n";
    cout << CYAN << "2. User (U)\n";
    cout << YELLOW << "Enter A for Admin or U for User: ";
    cin >> choice;
    if (choice == 'A' || choice == 'a') {
        adminLogin();
    }
    else if (choice == 'U' || choice == 'u') {
        userPage();
    }
    else {
        cout << RED << "Invalid option\n";
        displayWelcomePage();
    }
}
int main() {
    initializeUserCounts();  // Initialize user counts
    displayWelcomePage();
    return 0;
}